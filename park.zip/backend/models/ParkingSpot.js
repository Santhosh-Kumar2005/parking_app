// backend/models/ParkingSpot.js
const mongoose = require('mongoose');

const parkingSpotSchema = new mongoose.Schema({
  lotId: { type: mongoose.Schema.Types.ObjectId, ref: 'ParkingLot', required: true },
  status: { type: String, enum: ['A', 'O'], default: 'A' },
  spotIndex: { type: Number, default: 0 }, // For labeling A-1, etc.
}, { timestamps: true });

module.exports = mongoose.model('ParkingSpot', parkingSpotSchema);