const express = require('express');
const jwt = require('jsonwebtoken');
const ParkingLot = require('../models/ParkingLot');
const ParkingSpot = require('../models/ParkingSpot');
const Reservation = require('../models/Reservation');
const User = require('../models/User');
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || 'your-jwt-secret-key-change-this';

// Middleware to check admin
const isAdmin = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      console.log('No token provided for ${req.path}');
      return res.status(401).json({ message: 'No token, authorization denied' });
    }
    const decoded = jwt.verify(token, JWT_SECRET);
    console.log('Decoded token for ${req.path}:', decoded.role);
    const user = await User.findById(decoded.userId);
    if (!user || user.role !== 'admin') {
      console.log('Invalid role for ${req.path}:', user?.role);
      return res.status(403).json({ message: 'Admin access required' });
    }
    req.user = user;
    next();
  } catch (err) {
    console.error('JWT error for ${req.path}:', err.message);
    res.status(401).json({ message: 'Token is not valid' });
  }
};

router.use(isAdmin);

// Get lots - FIXED: Ensure this route is defined
router.get('/lots', async (req, res) => {
  try {
    const { query } = req.query;
    let filter = {};
    if (query) {
      filter.primeLocationName = { $regex: query, $options: 'i' };
    }
    const lots = await ParkingLot.find(filter).lean();
    console.log(`Admin fetched ${lots.length} lots for query "${query}"`);
    res.json(lots);
  } catch (err) {
    console.error('Get lots error:', err);
    res.status(500).json({ message: err.message });
  }
});

// Create lot
router.post('/lots', async (req, res) => {
  try {
    console.log('Admin add lot body:', req.body);
    const lot = new ParkingLot(req.body);
    await lot.save();
    console.log('Admin saved lot ID:', lot._id);
    for (let i = 1; i <= lot.maximumNumberOfSpots; i++) {
      const spot = new ParkingSpot({ lotId: lot._id, spotIndex: i });
      await spot.save();
    }
    console.log(`Admin added lot "${lot.primeLocationName}" with ${lot.maximumNumberOfSpots} spots`);
    res.status(201).json(lot);
  } catch (err) {
    console.error('Admin add lot error:', err.message);
    res.status(500).json({ message: err.message });
  }
});

// Update lot
router.put('/lots/:id', async (req, res) => {
  try {
    const lot = await ParkingLot.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!lot) return res.status(404).json({ message: 'Lot not found' });
    res.json(lot);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Delete lot
router.delete('/lots/:id', async (req, res) => {
  try {
    const lot = await ParkingLot.findById(req.params.id);
    if (!lot) return res.status(404).json({ message: 'Lot not found' });
    await ParkingSpot.deleteMany({ lotId: lot._id });
    await Reservation.deleteMany({ spotId: { $in: await ParkingSpot.distinct('_id', { lotId: lot._id }) } });
    await ParkingLot.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get spots with details
router.get('/spots/details', async (req, res) => {
  try {
    const spots = await ParkingSpot.aggregate([
      { $lookup: { from: 'parkinglots', localField: 'lotId', foreignField: '_id', as: 'lot' } },
      { $unwind: { path: '$lot', preserveNullAndEmptyArrays: true } },
      { $lookup: { 
        from: 'reservations', 
        localField: '_id', 
        foreignField: 'spotId', 
        as: 'reservation', 
        pipeline: [{ $match: { leavingTimestamp: null } }] 
      } },
      { $unwind: { path: '$reservation', preserveNullAndEmptyArrays: true } },
      { $lookup: { from: 'users', localField: 'reservation.userId', foreignField: '_id', as: 'user' } },
      { $unwind: { path: '$user', preserveNullAndEmptyArrays: true } },
      { $addFields: {
          label: { $concat: [ 
            { $substr: [{ $toString: { $mod: [{ $add: [{ $subtract: ['$spotIndex', 1] }, 65] }, 26] } }, 0, 1] }, 
            '-', { $toString: '$spotIndex' } 
          ] },
          lotName: { $ifNull: ['$lot.primeLocationName', ''] },
          username: { $ifNull: ['$user.username', ''] },
          vehicleNumber: { $ifNull: ['$reservation.vehicleNumber', ''] },
          parkingTimestamp: { $ifNull: ['$reservation.parkingTimestamp', ''] },
          status: { $cond: [ 
            { $eq: [ { $size: { $ifNull: ['$reservation', []] } }, 0 ] },
            'A', 
            'O' 
          ] }
        }
      },
      { $project: { lot: 0, reservation: 0, user: 0, spotIndex: 0 } }
    ]);
    console.log(`Admin fetched ${spots.length} spots`);
    res.json(spots);
  } catch (err) {
    console.error('Get spots error:', err.message);
    res.status(500).json({ message: err.message });
  }
});

// Get spot details
router.get('/spots/:id/details', async (req, res) => {
  try {
    const spot = await ParkingSpot.findById(req.params.id).populate('lotId');
    const reservation = await Reservation.findOne({ spotId: req.params.id, leavingTimestamp: null }).populate('userId');
    res.json({
      id: spot._id,
      lotId: spot.lotId._id,
      status: spot.status,
      userId: reservation?.userId?.username || '',
      vehicleNumber: reservation?.vehicleNumber || '',
      parkingTimestamp: reservation?.parkingTimestamp || '',
      leavingTimestamp: reservation?.leavingTimestamp || '',
      parkingCost: reservation?.parkingCost || null,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Summary
router.get('/summary', async (req, res) => {
  try {
    const totalSpots = await ParkingSpot.countDocuments();
    const occupiedSpots = await ParkingSpot.countDocuments({ status: 'O' });
    const availableSpots = totalSpots - occupiedSpots;
    const users = await User.find({}, 'username role').lean(); // FIXED: Ensure users load

    // FIXED: User revenues - Include unreleased with projected cost
    const userRevenues = await Reservation.aggregate([
      { $lookup: { from: 'parkingspots', localField: 'spotId', foreignField: '_id', as: 'spot' } },
      { $unwind: { path: '$spot', preserveNullAndEmptyArrays: true } },
      { $lookup: { from: 'parkinglots', localField: 'spot.lotId', foreignField: '_id', as: 'lot' } },
      { $unwind: { path: '$lot', preserveNullAndEmptyArrays: true } },
      {
        $addFields: {
          // Projected cost for unreleased: hours parked * price
          projectedCost: {
            $cond: {
              if: { $eq: ['$leavingTimestamp', null] },
              then: { $multiply: [{ $divide: [{ $subtract: [new Date(), '$parkingTimestamp'] }, 3600000] }, '$lot.price'] }, // ms to hours
              else: '$parkingCost'
            }
          }
        }
      },
      { $group: { _id: '$userId', revenue: { $sum: '$projectedCost' } } },
      { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
      { $unwind: { path: '$user', preserveNullAndEmptyArrays: true } },
      { $project: { username: '$user.username', role: '$user.role', revenue: { $round: ['$revenue', 2] } } }
    ]);

    // FIXED: Lot revenues - Group by unique lot._id, project lotName
    const lotRevenues = await Reservation.aggregate([
      { $match: { leavingTimestamp: { $ne: null } } }, // Released only
      { $lookup: { from: 'parkingspots', localField: 'spotId', foreignField: '_id', as: 'spot' } },
      { $unwind: { path: '$spot', preserveNullAndEmptyArrays: true } },
      { $lookup: { from: 'parkinglots', localField: 'spot.lotId', foreignField: '_id', as: 'lot' } },
      { $unwind: { path: '$lot', preserveNullAndEmptyArrays: true } },
      { $group: { _id: { $toString: '$lot._id' }, lotName: { $first: '$lot.primeLocationName' }, revenue: { $sum: '$parkingCost' } } }, // FIXED: Group by string _id
      { $project: { lotId: '$_id', lotName: 1, revenue: { $round: ['$revenue', 2] } } } // FIXED: Project lotId for frontend match
    ]);

    const totalRevenue = lotRevenues.reduce((sum, lot) => sum + (lot.revenue || 0), 0);
    res.json({
      occupiedSpots,
      availableSpots,
      users: users.map(u => ({
        id: u._id,
        username: u.username,
        role: u.role,
        revenue: userRevenues.find(ur => ur._id?.toString() === u._id.toString())?.revenue || 0
      })),
      lotRevenue: lotRevenues,
      totalRevenue: Math.round(totalRevenue * 100) / 100, // Round to 2 decimals
    });
  } catch (err) {
    console.error('Summary error:', err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;