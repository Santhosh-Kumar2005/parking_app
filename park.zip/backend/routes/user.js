// backend/routes/user.js
const express = require('express');
const jwt = require('jsonwebtoken');
const ParkingSpot = require('../models/ParkingSpot');
const Reservation = require('../models/Reservation');
const User = require('../models/User');
const ParkingLot = require('../models/ParkingLot');
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || 'your-jwt-secret-key-change-this';

// Middleware to check user (JWT)
const isUser = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ message: 'No token, authorization denied' });
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.userId);
    if (!user || user.role !== 'user') return res.status(403).json({ message: 'User access required' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token is not valid' });
  }
};

// Public: Get lots (no auth) - same as previous user GET /lots
router.get('/lots', async (req, res) => {
  try {
    const { query } = req.query;
    let filter = {};
    if (query) {
      filter.primeLocationName = { $regex: query, $options: 'i' };
    }
    const lots = await ParkingLot.find(filter);
    // Add availability
    for (let lot of lots) {
      const spots = await ParkingSpot.countDocuments({ lotId: lot._id, status: 'A' });
      lot.availability = `${spots}/${lot.maximumNumberOfSpots}`;
    }
    res.json(lots);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/spots/details', async (req, res) => {
  try {
    // Try advanced aggregate (match populated spots with lot details)
    const spots = await ParkingSpot.aggregate([
      {
        $lookup: {
          from: 'parkinglots', // FIXED: Ensure collection name matches model (lowercase)
          localField: 'lotId',
          foreignField: '_id',
          as: 'lot',
        },
      },
      { $unwind: '$lot' },
      {
        $lookup: {
          from: 'reservations',
          let: { spotId: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ['$spotId', '$$spotId'] },
                leavingTimestamp: { $eq: null }, // Current reservations only
              },
            },
            { $limit: 1 },
          ],
          as: 'currentReservation',
        },
      },
      { $unwind: { path: '$currentReservation', preserveNullAndEmptyArrays: true } },
      {
        $addFields: {
          status: { $cond: [{ $ifNull: ['$currentReservation', false] }, 'O', 'A'] },
          vehicleNumber: { $ifNull: ['$currentReservation.vehicleNumber', null] },
          label: { $concat: ['$lot.primeLocationName', '-', { $toString: '$spotIndex' }] },
        },
      },
      {
        $project: {
          _id: 1,
          lotId: '$lot._id',
          status: 1,
          label: 1,
          vehicleNumber: 1,
          primeLocationName: '$lot.primeLocationName',
          price: '$lot.price',
        },
      },
      { $sort: { 'lot.primeLocationName': 1, spotIndex: 1 } },
    ]);

    if (spots.length === 0) {
      console.log('No spots found in aggregate; falling back to simple query');
      // FIXED: Fallback to basic count/query if aggregate fails
      const basicSpots = await ParkingSpot.find({}).populate('lotId', 'primeLocationName price').lean();
      return res.json(basicSpots.map(s => ({
        _id: s._id,
        lotId: s.lotId._id,
        status: 'A', // Assume available if no resv check
        label: `${s.lotId.primeLocationName}-1`, // Simple label
        vehicleNumber: null,
      })));
    }

    console.log(`Fetched ${spots.length} spots with details`);
    res.json(spots);
  } catch (err) {
    console.error('Spots/details aggregate error:', err); // FIXED: Log full error
    // Graceful fallback: Return empty or simple data
    res.status(200).json([]); // Avoid 500; let frontend handle empty
  }
});

// Public: summary (no auth)
router.get('/summary', async (req, res) => {
  try {
    const totalSpots = await ParkingSpot.countDocuments();
    const occupiedSpots = await ParkingSpot.countDocuments({ status: 'O' });
    const availableSpots = totalSpots - occupiedSpots;
    res.json({ occupiedSpots, availableSpots });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// The reservation routes require a user token
router.post('/reservations', isUser, async (req, res) => {
  try {
    const { lotId, userId, vehicleNumber } = req.body;
    if (!/^[A-Z]{2}\d{1,2}[A-Z]{1,2}\d{4}$/.test(vehicleNumber)) {
      return res.status(400).json({ message: 'Invalid vehicle number' });
    }
    const existingVehicle = await Reservation.findOne({ vehicleNumber, leavingTimestamp: null });
    if (existingVehicle) {
      return res.status(400).json({ message: 'Vehicle already reserved' });
    }
    const userRes = await Reservation.findOne({ userId, leavingTimestamp: null });
    if (userRes) {
      return res.status(400).json({ message: 'User already has active reservation' });
    }
    const availableSpot = await ParkingSpot.findOne({ lotId, status: 'A' }).sort({ spotIndex: 1 });
    if (!availableSpot) {
      return res.status(400).json({ message: 'No available spots in this lot' });
    }
    availableSpot.status = 'O';
    await availableSpot.save();
    const reservation = new Reservation({ spotId: availableSpot._id, userId, vehicleNumber });
    await reservation.save();
    res.status(201).json(reservation);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.put('/reservations/:id/release', isUser, async (req, res) => {
  try {
    const reservation = await Reservation.findById(req.params.id).populate('spotId');
    if (!reservation || reservation.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }
    reservation.leavingTimestamp = new Date();
    const spot = reservation.spotId;
    const lot = await ParkingLot.findById(spot.lotId);
    const timeParked = (reservation.leavingTimestamp - reservation.parkingTimestamp) / (1000 * 60 * 60);
    reservation.parkingCost = lot.price * timeParked;
    spot.status = 'A';
    await spot.save();
    await reservation.save();
    res.json({ message: 'Released', cost: reservation.parkingCost });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/reservations', isUser, async (req, res) => {
  try {
    const reservations = await Reservation.find({ userId: req.user._id })
      .sort({ parkingTimestamp: -1 })
      .populate('spotId', 'lotId spotIndex')
      .lean();
    // Add lot name
    for (let resv of reservations) {
      const spot = resv.spotId;
      const lot = await ParkingLot.findById(spot.lotId);
      resv.lotId = lot ? lot._id : 'N/A';
    }
    res.json(reservations);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;