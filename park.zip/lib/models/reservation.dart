// lib/models/reservation.dart
import 'package:intl/intl.dart';

class Reservation {
  final String id;
  final String spotId;
  final String userId;
  final String vehicleNumber;
  final DateTime parkingTimestamp;
  final DateTime? leavingTimestamp;
  final double? parkingCost;
  final String? lotId; // FIXED: Added for populated lotId from response

  Reservation({
    required this.id,
    required this.spotId,
    required this.userId,
    required this.vehicleNumber,
    required this.parkingTimestamp,
    this.leavingTimestamp,
    this.parkingCost,
    this.lotId,
  });

  // FIXED: Made static to allow access from factory constructor
  static String _getDateString(dynamic val) {
    if (val is String) return val;
    if (val is Map<String, dynamic> && val.containsKey(r'$date')) {
      return val[r'$date'] as String? ?? DateTime.now().toIso8601String();
    }
    print('Warning: Invalid date format: $val'); // Log for debugging
    return DateTime.now().toIso8601String(); // Fallback
  }

  factory Reservation.fromJson(Map<String, dynamic> json) {
    try {
      // FIXED: Extract string ID from populated spotId object
      final spotObj = json['spotId'] as Map<String, dynamic>?;
      final spotIdStr =
          spotObj?['_id']?.toString() ?? json['spotId']?.toString() ?? '';

      return Reservation(
        id: json['_id'] ?? json['id'] ?? '', // Handle both _id and id
        spotId: spotIdStr,
        userId: json['userId']?.toString() ?? '',
        vehicleNumber: json['vehicleNumber']?.toString() ?? '',
        parkingTimestamp: DateTime.parse(
          _getDateString(json['parkingTimestamp']),
        ),
        leavingTimestamp: json['leavingTimestamp'] != null
            ? DateTime.parse(_getDateString(json['leavingTimestamp']))
            : null,
        parkingCost: (json['parkingCost'] as num?)?.toDouble(),
        lotId: json['lotId']?.toString(), // FIXED: Handle populated lotId
      );
    } catch (e) {
      print('Full parse error in fromJson: $e');
      print('JSON: $json');
      // Fallback to minimal instance (for graceful degradation)
      rethrow; // Or return a default; rethrow for now to log
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'spotId': spotId,
      'userId': userId,
      'vehicleNumber': vehicleNumber,
      'parkingTimestamp': parkingTimestamp.toIso8601String(),
      'leavingTimestamp': leavingTimestamp?.toIso8601String(),
      'parkingCost': parkingCost,
      if (lotId != null) 'lotId': lotId,
    };
  }

  String get formattedParkingTime =>
      DateFormat('yyyy-MM-dd HH:mm:ss').format(parkingTimestamp);
  String get formattedLeavingTime => leavingTimestamp != null
      ? DateFormat('yyyy-MM-dd HH:mm:ss').format(leavingTimestamp!)
      : 'Still Parked';
}
