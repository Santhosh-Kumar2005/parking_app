// lib/models/parking_lot.dart
class ParkingLot {
  final String? id;
  final String? primeLocationName;
  final double? price;
  final String? address;
  final String? pinCode;
  final int? maximumNumberOfSpots;
  String? availability; // Add this field for storing availability info

  ParkingLot({
    this.id,
    this.primeLocationName,
    this.price,
    this.address,
    this.pinCode,
    this.maximumNumberOfSpots,
    this.availability,
  });

  factory ParkingLot.fromJson(Map<String, dynamic> json) {
    return ParkingLot(
      id: json['_id'] as String?,
      primeLocationName: json['primeLocationName'] as String?,
      price: (json['price'] as num?)?.toDouble(),
      address: json['address'] as String?,
      pinCode: json['pinCode'] as String?,
      maximumNumberOfSpots: json['maximumNumberOfSpots'] as int?,
      availability: json['availability'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'primeLocationName': primeLocationName,
      'price': price,
      'address': address,
      'pinCode': pinCode,
      'maximumNumberOfSpots': maximumNumberOfSpots,
      'availability': availability,
    };
  }
}
