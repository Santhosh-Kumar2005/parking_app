import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:convert'; // For jsonDecode logging
import '../services/auth_service.dart';
import '../services/api_service.dart';
import '../models/parking_lot.dart';
import 'add_lot_screen.dart';
import 'edit_lot_screen.dart';
import 'spot_details_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  _AdminDashboardScreenState createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<ParkingLot> lots = [];
  List<Map<String, dynamic>> spotsWithDetails = [];
  Map<String, dynamic> summary = {};
  final _searchController = TextEditingController();

  bool _isLoading = false; // Prevent multiple simultaneous loads

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData({String? query}) async {
    if (!mounted || _isLoading) return; // Guard against dispose and duplicates
    _isLoading = true;
    print('Loading data... Query: $query');
    try {
      lots = await ApiService.getParkingLots(query: query);
      print(
        'Loaded ${lots.length} lots: ${lots.map((l) => l.primeLocationName).toList()}',
      );
      spotsWithDetails = await ApiService.getSpotsWithDetails();
      print('Loaded ${spotsWithDetails.length} spots');
      summary = await ApiService.getSummary();
      print('Summary loaded: ${summary['occupiedSpots']} occupied');
      if (mounted) {
        setState(() {}); // Safe setState
        print('setState called - UI should update');
      }
    } catch (e) {
      print('Load error: $e');
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Load failed: $e')));
      }
    } finally {
      _isLoading = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome to Admin Dashboard'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Parking Lots'),
            Tab(text: 'Add Lot'),
            Tab(text: 'Summary Charts'),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              context.read<AuthService>().logout();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildLotsTab(),
          AddLotScreen(
            onAdded: () => _loadData(),
          ), // FIXED: Call refresh after add
          _buildSummaryTab(),
        ],
      ),
    );
  }

  Widget _buildLotsTab() {
    final filteredLots = lots
        .where(
          (lot) => (lot.primeLocationName?.toLowerCase() ?? '').contains(
            _searchController.text.toLowerCase(),
          ),
        )
        .toList();
    final filteredSpots = spotsWithDetails
        .where(
          (spot) =>
              ((spot['lotName'] as String?)?.toLowerCase() ?? '').contains(
                _searchController.text.toLowerCase() ?? '',
              ) ||
              ((spot['vehicleNumber'] as String?)?.toLowerCase() ?? '')
                  .contains(_searchController.text.toLowerCase() ?? ''),
        )
        .toList();

    // REPLACED: Use horizontal scroll + fixed column widths + ellipsis to avoid overflow
    Widget lotsTable() {
      return SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ConstrainedBox(
          constraints: BoxConstraints(
            minWidth: MediaQuery.of(context).size.width,
          ),
          child: DataTable(
            columnSpacing: 24,
            headingRowHeight: 56,
            columns: [
              DataColumn(
                label: SizedBox(
                  width: 220,
                  child: Text('ID', overflow: TextOverflow.ellipsis),
                ),
              ),
              DataColumn(
                label: SizedBox(
                  width: 180,
                  child: Text('Location Name', overflow: TextOverflow.ellipsis),
                ),
              ),
              DataColumn(
                label: SizedBox(
                  width: 120,
                  child: Text(
                    'Price per Hour',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
              DataColumn(
                label: SizedBox(
                  width: 200,
                  child: Text('Address', overflow: TextOverflow.ellipsis),
                ),
              ),
              DataColumn(
                label: SizedBox(
                  width: 100,
                  child: Text('Pin Code', overflow: TextOverflow.ellipsis),
                ),
              ),
              DataColumn(
                label: SizedBox(
                  width: 120,
                  child: Text('Max Spots', overflow: TextOverflow.ellipsis),
                ),
              ),
              DataColumn(
                label: SizedBox(
                  width: 180,
                  child: Text('Actions', overflow: TextOverflow.ellipsis),
                ),
              ),
            ],
            rows: filteredLots.map((lot) {
              return DataRow(
                cells: [
                  DataCell(
                    SizedBox(
                      width: 220,
                      child: Text(
                        lot.id ?? '',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  DataCell(
                    SizedBox(
                      width: 180,
                      child: Text(
                        lot.primeLocationName ?? '',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  DataCell(
                    SizedBox(
                      width: 120,
                      child: Text(
                        '₹${lot.price}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  DataCell(
                    SizedBox(
                      width: 200,
                      child: Text(
                        lot.address ?? '',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  DataCell(
                    SizedBox(
                      width: 100,
                      child: Text(
                        lot.pinCode ?? '',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  DataCell(
                    SizedBox(
                      width: 120,
                      child: Text(
                        '${lot.maximumNumberOfSpots}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  // ACTIONS: wrap in FittedBox so buttons scale down instead of overflowing
                  DataCell(
                    SizedBox(
                      width: 180,
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => EditLotScreen(
                                      lot: lot,
                                      onUpdated: () => _loadData(),
                                    ),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.yellow[700],
                                minimumSize: Size(64, 36),
                                padding: EdgeInsets.symmetric(horizontal: 12),
                              ),
                              child: Text('Edit'),
                            ),
                            SizedBox(width: 8),
                            ElevatedButton(
                              onPressed: () {
                                if (lot.id != null) {
                                  ApiService.deleteParkingLot(
                                    lot.id!,
                                  ).then((_) => _loadData());
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                                minimumSize: Size(64, 36),
                                padding: EdgeInsets.symmetric(horizontal: 12),
                              ),
                              child: Text('Delete'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            }).toList(),
          ),
        ),
      );
    }

    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Parking Lots',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              ElevatedButton(
                onPressed: _isLoading ? null : _loadData,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                ), // Disable during load
                child: _isLoading
                    ? CircularProgressIndicator()
                    : Text('Refresh'),
              ),
            ],
          ),
          SizedBox(height: 8),
          TextField(
            controller: _searchController,
            decoration: InputDecoration(
              labelText: 'Search by parking lot or vehicle/location',
              suffixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
            ),
            onChanged: (value) => setState(() {}),
          ),
          SizedBox(height: 16),
          if (filteredLots.isEmpty)
            Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    Icon(Icons.inbox, size: 64, color: Colors.grey),
                    Text('No lots found. Add one from the "Add Lot" tab!'),
                  ],
                ),
              ),
            )
          else
            lotsTable(),
          SizedBox(height: 24),
          Text(
            'Parking Spots',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          SizedBox(height: 16),
          if (filteredSpots.isEmpty)
            Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    Icon(Icons.inbox, size: 64, color: Colors.grey),
                    Text('No spots found. Add a lot to create spots!'),
                  ],
                ),
              ),
            )
          else
            DataTable(
              key: ValueKey('spots-${filteredSpots.length}'),
              columns: [
                DataColumn(label: Text('Spot ID')),
                DataColumn(label: Text('Parking Lot Name')),
                DataColumn(label: Text('Status')),
                DataColumn(label: Text('User')),
                DataColumn(label: Text('Vehicle Number')),
                DataColumn(label: Text('Parking Since')),
                DataColumn(label: Text('Action')),
              ],
              rows: filteredSpots
                  .map(
                    (spotData) => DataRow(
                      color: MaterialStateProperty.all(
                        (spotData['status'] == 'O' ? Colors.red : Colors.green)
                            .withOpacity(0.1),
                      ),
                      cells: [
                        DataCell(Text(spotData['label'] ?? 'N/A')),
                        DataCell(Text(spotData['lotName'] ?? 'N/A')),
                        DataCell(
                          Text(
                            spotData['status'] ?? 'N/A',
                            style: TextStyle(
                              color: spotData['status'] == 'O'
                                  ? Colors.red
                                  : Colors.green,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        DataCell(Text(spotData['username'] ?? 'N/A')),
                        DataCell(Text(spotData['vehicleNumber'] ?? 'N/A')),
                        DataCell(Text(spotData['parkingTimestamp'] ?? 'N/A')),
                        DataCell(
                          ElevatedButton(
                            onPressed:
                                (spotData['_id'] != null &&
                                    spotData['_id'].toString().isNotEmpty)
                                ? () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => SpotDetailsScreen(
                                        spotId: spotData['_id'].toString(),
                                      ),
                                    ),
                                  )
                                : null,
                            child: Text('Details'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                  .toList(),
            ),
        ],
      ),
    );
  }

  Widget _buildSummaryTab() {
    final occupied = summary['occupiedSpots'] ?? 0;
    final available = summary['availableSpots'] ?? 0;
    final lotRevenues = List<Map<String, dynamic>>.from(
      summary['lotRevenue'] ?? [],
    );

    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    'Total Spots Chart',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: 16),
                  SizedBox(
                    height: 200,
                    child: DoughnutChart(
                      occupied: occupied.toDouble(),
                      available: available.toDouble(),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 16),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    'Parking Lot Revenue',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: 16),
                  SizedBox(
                    height: 200,
                    child: BarChartWidget(lotRevenues: lotRevenues),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 16),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Registered Users',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  DataTable(
                    key: UniqueKey(),
                    columns: [
                      DataColumn(label: Text('ID')),
                      DataColumn(label: Text('Username')),
                      DataColumn(label: Text('Role')),
                      DataColumn(label: Text('Revenue')),
                    ],
                    rows: (summary['users'] ?? [])
                        .map<DataRow>(
                          (user) => DataRow(
                            cells: [
                              DataCell(Text(user['id'] ?? 'N/A')), // Null guard
                              DataCell(Text(user['username'] ?? 'N/A')),
                              DataCell(Text(user['role'] ?? 'N/A')),
                              DataCell(
                                Text(
                                  '₹${(user['revenue'] ?? 0).toStringAsFixed(2)}',
                                ),
                              ),
                            ],
                          ),
                        )
                        .toList(),
                  ),
                  Divider(),
                  Text(
                    'Total Revenue: ₹${(summary['totalRevenue'] ?? 0).toStringAsFixed(2)}',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 16),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'LOT REVENUE',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  DataTable(
                    key: UniqueKey(),
                    columns: [
                      DataColumn(label: Text('ID')),
                      DataColumn(label: Text('Lot Name')),
                      DataColumn(label: Text('Revenue')),
                    ],
                    // In LOT REVENUE DataTable rows:
                    rows: lots.map<DataRow>((lot) {
                      // FIXED: Match by lotId (string) == lot.id
                      final rev =
                          lotRevenues.firstWhere(
                            (r) => (r['lotId'] ?? '') == lot.id,
                            orElse: () => {'revenue': 0},
                          )['revenue'] ??
                          0;
                      return DataRow(
                        cells: [
                          DataCell(
                            Text(
                              ((lot.id?.length ?? 0) > 16)
                                  ? '${lot.id?.substring(0, 16)}...'
                                  : lot.id ?? 'N/A',
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                          DataCell(Text(lot.primeLocationName ?? 'N/A')),
                          DataCell(Text('₹${rev.toStringAsFixed(2)}')),
                        ],
                      );
                    }).toList(),
                  ),
                  Divider(),
                  Text(
                    'Total Revenue: ₹${(summary['totalRevenue'] ?? 0).toStringAsFixed(2)}',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class DoughnutChart extends StatelessWidget {
  final double occupied;
  final double available;

  const DoughnutChart({
    super.key,
    required this.occupied,
    required this.available,
  });

  @override
  Widget build(BuildContext context) {
    return PieChart(
      PieChartData(
        sections: [
          PieChartSectionData(
            value: occupied,
            color: Colors.red,
            title: 'Occupied',
          ),
          PieChartSectionData(
            value: available,
            color: Colors.green,
            title: 'Available',
          ),
        ],
        centerSpaceRadius: 40,
      ),
    );
  }
}

class BarChartWidget extends StatelessWidget {
  final List<Map<String, dynamic>> lotRevenues;

  const BarChartWidget({super.key, required this.lotRevenues});

  @override
  Widget build(BuildContext context) {
    return BarChart(
      BarChartData(
        barGroups: lotRevenues
            .asMap()
            .entries
            .map(
              (entry) => BarChartGroupData(
                x: entry.key,
                barRods: [
                  BarChartRodData(
                    toY: entry.value['revenue'].toDouble(),
                    color: Colors.blue,
                  ),
                ],
              ),
            )
            .toList(),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                final index = value.toInt();
                if (index >= 0 && index < lotRevenues.length) {
                  return Text(lotRevenues[index]['_id'] ?? '');
                }
                return Text('');
              },
            ),
          ),
        ),
      ),
    );
  }
}
