import 'dart:convert';
import 'package:flutter/material.dart';
import '../services/api_service.dart';

class SpotDetailsScreen extends StatefulWidget {
  final String spotId;
  const SpotDetailsScreen({Key? key, required this.spotId}) : super(key: key);

  @override
  _SpotDetailsScreenState createState() => _SpotDetailsScreenState();
}

class _SpotDetailsScreenState extends State<SpotDetailsScreen> {
  Map<String, dynamic>? spotData;

  @override
  void initState() {
    super.initState();
    _loadSpotDetails();
  }

  Future<void> _loadSpotDetails() async {
    final response = await ApiService.getSpotDetails(widget.spotId);
    if (response.statusCode == 200) {
      setState(() {
        spotData = jsonDecode(response.body);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Spot Details')),
      body: spotData == null
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: EdgeInsets.all(16),
              child: Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Spot ID: ${spotData!['id'] ?? 'N/A'}', style: Theme.of(context).textTheme.titleLarge),
                      Text('Lot ID: ${spotData!['lotId'] ?? 'N/A'}'),
                      Text('Status: ${spotData!['status'] ?? 'N/A'}'),
                      Text('User ID: ${spotData!['userId'] ?? 'N/A'}'),
                      Text('Vehicle Number: ${spotData!['vehicleNumber'] ?? 'N/A'}'),
                      Text('Parking Time: ${spotData!['parkingTimestamp'] ?? 'N/A'}'),
                      Text('Leaving Time: ${spotData!['leavingTimestamp'] ?? 'Still Parked'}'),
                      Text('Cost: ${spotData!['parkingCost'] ?? 'N/A'}'),
                      SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text('Back'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}