// lib/screens/add_lot_screen.dart
import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/parking_lot.dart';

class AddLotScreen extends StatefulWidget {
  final VoidCallback onAdded;
  const AddLotScreen({Key? key, required this.onAdded}) : super(key: key);

  @override
  _AddLotScreenState createState() => _AddLotScreenState();
}

class _AddLotScreenState extends State<AddLotScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _addressController = TextEditingController();
  final _pinController = TextEditingController();
  final _maxSpotsController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    print('AddLotScreen initState - Building form'); // Debug: Confirm init
  }

  @override
  Widget build(BuildContext context) {
    print('AddLotScreen build - Rendering'); // Debug: Confirm build calls
    return Builder(
      // Safe context wrapper
      builder: (context) {
        try {
          return Scaffold(
            appBar: AppBar(
              title: Text('Add Parking Lot'),
              backgroundColor: Colors.blue,
              foregroundColor: Colors.white,
            ),
            body: Padding(
              padding: EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _nameController,
                        decoration: InputDecoration(
                          labelText: 'Prime Location Name',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.location_on),
                        ),
                        validator: (v) =>
                            v?.isEmpty ?? true ? 'Required' : null,
                      ),
                      SizedBox(height: 16),
                      TextFormField(
                        controller: _priceController,
                        decoration: InputDecoration(
                          labelText: 'Price per Hour (₹)',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.attach_money),
                        ),
                        keyboardType: TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        validator: (v) {
                          if (v?.isEmpty ?? true) return 'Required';
                          final num = double.tryParse(v!);
                          if (num == null || num <= 0)
                            return 'Must be positive number';
                          return null;
                        },
                      ),
                      SizedBox(height: 16),
                      TextFormField(
                        controller: _addressController,
                        decoration: InputDecoration(
                          labelText: 'Address',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.home),
                        ),
                        validator: (v) =>
                            v?.isEmpty ?? true ? 'Required' : null,
                      ),
                      SizedBox(height: 16),
                      TextFormField(
                        controller: _pinController,
                        decoration: InputDecoration(
                          labelText: 'Pin Code',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.pin_drop),
                        ),
                        keyboardType: TextInputType.number,
                        validator: (v) {
                          if (v?.isEmpty ?? true) return 'Required';
                          final num = int.tryParse(v!);
                          if (num == null || num < 10000 || num > 999999)
                            return 'Valid 5-6 digit pin';
                          return null;
                        },
                      ),
                      SizedBox(height: 16),
                      TextFormField(
                        controller: _maxSpotsController,
                        decoration: InputDecoration(
                          labelText: 'Maximum Number of Spots',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.local_parking),
                        ),
                        keyboardType: TextInputType.number,
                        validator: (v) {
                          if (v?.isEmpty ?? true) return 'Required';
                          final num = int.tryParse(v!);
                          if (num == null || num <= 0)
                            return 'Must be positive integer';
                          return null;
                        },
                      ),
                      SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _addLot,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            padding: EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: _isLoading
                              ? CircularProgressIndicator(color: Colors.white)
                              : Text(
                                  'Add Parking Lot',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        } catch (e) {
          print('Build error in AddLotScreen: $e'); // Catch silent errors
          return Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error, size: 64, color: Colors.red),
                  Text('Error loading form: $e'),
                  ElevatedButton(
                    onPressed: () => setState(() {}), // Retry build
                    child: Text('Retry'),
                  ),
                ],
              ),
            ),
          );
        }
      },
    );
  }

  Future<void> _addLot() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);
      try {
        final data = {
          'primeLocationName': _nameController.text.trim(),
          'price': double.parse(_priceController.text.trim()),
          'address': _addressController.text.trim(),
          'pinCode': _pinController.text.trim(),
          'maximumNumberOfSpots': int.parse(_maxSpotsController.text.trim()),
        };
        print('Sending data to backend: $data');
        final lot = await ApiService.createParkingLot(data);
        print('API Response: $lot'); // Log full response
        if (lot != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Lot added successfully!'),
              backgroundColor: Colors.green,
            ),
          );
          // REMOVED: widget.onAdded(); and Navigator.pop(context); - Stay on screen, show message
          // Clear form for next add
          _nameController.clear();
          _priceController.clear();
          _addressController.clear();
          _pinController.clear();
          _maxSpotsController.clear();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to add lot. Check backend.'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } catch (e) {
        print('Error adding lot: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      } finally {
        if (mounted) setState(() => _isLoading = false);
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _addressController.dispose();
    _pinController.dispose();
    _maxSpotsController.dispose();
    super.dispose();
  }
}
