// lib/screens/user_dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:math' as math;
import '../services/auth_service.dart';
import '../services/api_service.dart';
import '../models/parking_lot.dart';
import '../models/reservation.dart';
import '../models/parking_spot.dart';

// Compatibility shim: provide a nullable `token` getter if AuthService doesn't expose one.
extension AuthServiceTokenExtension on AuthService {
  String? get token => null;
}

class UserDashboardScreen extends StatefulWidget {
  @override
  _UserDashboardScreenState createState() => _UserDashboardScreenState();
}

class _UserDashboardScreenState extends State<UserDashboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<ParkingLot> lots = [];
  List<Map<String, dynamic>> spotsWithDetails =
      []; // FIXED: Fetch spots for user
  List<Reservation> history = [];
  Reservation? currentReservation;
  Map<String, dynamic> summary = {};
  final _searchController = TextEditingController();
  final _vehicleController = TextEditingController();
  String? selectedLotId;
  String query = '';
  bool _isLoading = false; // FIXED: Prevent duplicate loads

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _vehicleController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    if (_isLoading || !mounted) return; // FIXED: Guard duplicates & dispose
    _isLoading = true;
    final auth = context.read<AuthService>();
    final userId = auth.userId ?? '';
    final token = auth.token;

    try {
      lots = await ApiService.getParkingLots(query: query, token: token);
      spotsWithDetails = await ApiService.getSpotsWithDetails(token: token);
      if (spotsWithDetails is! List<Map<String, dynamic>>) {
        print(
          'Invalid spots type: ${spotsWithDetails.runtimeType} - defaulting to []',
        );
        spotsWithDetails = [];
      }
      final reservationsRaw = await ApiService.getReservations(
        userId: userId,
        token: token,
      );
      // FIXED: Filter valid maps, handle parse errors
      history = reservationsRaw
          .where((r) => r is Map<String, dynamic>)
          .map((r) {
            try {
              return Reservation.fromJson(r as Map<String, dynamic>);
            } catch (e) {
              print('Failed to parse reservation: $r - Error: $e');
              return null;
            }
          })
          .where((r) => r != null)
          .cast<Reservation>()
          .toList();
      try {
        currentReservation = history.firstWhere(
          (r) => r.leavingTimestamp == null,
        );
      } catch (_) {
        currentReservation = null;
      }
      summary = await ApiService.getSummary(token: token);
      if (summary is! Map<String, dynamic>) summary = {};
    } catch (e) {
      print('_loadData error: $e');
      // Safe defaults
      spotsWithDetails = [];
      history = [];
      currentReservation = null;
      summary = {};
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Load failed: $e')));
      }
    } finally {
      _isLoading = false;
      if (mounted) setState(() {}); // FIXED: Mounted check
    }
  }

  Future<void> _reserveSpot() async {
    if (selectedLotId == null || _vehicleController.text.isEmpty) return;
    final auth = context.read<AuthService>();
    final userId = auth.userId;
    if (userId == null || userId.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Please login')));
      return;
    }
    try {
      final success = await ApiService.reserveSpot(
        selectedLotId!,
        userId,
        _vehicleController.text,
      );
      if (success) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Reserved!')));
        _vehicleController.clear();
        selectedLotId = null;
        await _loadData(); // FIXED: Safe refresh
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Reserve failed')));
      }
    } catch (e) {
      print('Reserve error: $e');
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome to User Dashboard'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Parking Lots'),
            Tab(text: 'Recent Parking History'),
            Tab(text: 'Summary Charts'),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              context.read<AuthService>().logout();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [_buildLotsTab(), _buildHistoryTab(), _buildSummaryTab()],
      ),
    );
  }

  Widget _buildLotsTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Reserve a Parking Spot',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      labelText: 'Search Lots',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (value) {
                      setState(() => query = value);
                      _loadData();
                    },
                  ),
                  SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: selectedLotId,
                    decoration: InputDecoration(
                      labelText: 'Select Parking Lot',
                      border: OutlineInputBorder(),
                    ),
                    items: lots
                        .map(
                          (lot) => DropdownMenuItem(
                            value: lot.id,
                            child: Text(lot.primeLocationName ?? ''),
                          ),
                        )
                        .toList(),
                    onChanged: (value) => setState(() => selectedLotId = value),
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: _vehicleController,
                    decoration: InputDecoration(
                      labelText: 'Vehicle Number',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.text,
                  ),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _reserveSpot,
                    child: Text('Reserve Spot'),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 16),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Available Spots',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  if (spotsWithDetails.isEmpty)
                    Padding(
                      padding: EdgeInsets.all(16),
                      child: Text('No spots available (check connection)'),
                    )
                  else
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Total Spots: ${spotsWithDetails.length}',
                        ), // FIXED: Add count for debug
                        // FIXED: Removed fixed height to show all; shrinkWrap + parent scroll handles it
                        GridView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: math.max(0, spotsWithDetails.length),
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                childAspectRatio: 1,
                                crossAxisSpacing: 4,
                                mainAxisSpacing:
                                    4, // FIXED: Add spacing for better layout
                              ),
                          itemBuilder: (context, index) {
                            if (index >= spotsWithDetails.length)
                              return SizedBox.shrink();
                            final spot =
                                spotsWithDetails[index]
                                    as Map<String, dynamic>? ??
                                {};
                            final isOccupied = (spot['status'] ?? 'A') == 'O';
                            final label =
                                spot['label']?.toString() ??
                                'Spot ${index + 1}'; // FIXED: Fallback if label missing
                            final vehicle =
                                spot['vehicleNumber']?.toString() ?? '';
                            return Card(
                              color: isOccupied
                                  ? Colors.red.shade100
                                  : Colors.green.shade100,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.local_parking,
                                    color: isOccupied
                                        ? Colors.red
                                        : Colors.green,
                                    size:
                                        40, // FIXED: Larger icon for visibility
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    label,
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ), // FIXED: Smaller text to fit
                                    textAlign: TextAlign.center,
                                  ),
                                  if (isOccupied && vehicle.isNotEmpty)
                                    Padding(
                                      padding: EdgeInsets.only(top: 2),
                                      child: Text(
                                        vehicle,
                                        style: TextStyle(
                                          fontSize: 8,
                                          color: Colors.grey[600],
                                        ),
                                        textAlign: TextAlign.center,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryTab() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal, // Scroll for long rows
      child: DataTable(
        horizontalMargin: 8.0, // Padding to reduce overflow
        columns: [
          DataColumn(label: Text('ID')),
          DataColumn(label: Text('Spot ID')),
          DataColumn(label: Text('Lot ID')),
          DataColumn(label: Text('Parking Time')),
          DataColumn(label: Text('Leaving Time')),
          DataColumn(label: Text('Cost')),
          DataColumn(label: Text('Actions')), // FIXED: New column for button
        ],
        rows: history
            .map(
              (res) => DataRow(
                cells: [
                  DataCell(
                    Text(
                      res.id.length > 16
                          ? '${res.id.substring(0, 16)}...'
                          : res.id,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                  ),
                  DataCell(
                    Text(
                      res.spotId.length > 16
                          ? '${res.spotId.substring(0, 16)}...'
                          : res.spotId,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                  ),
                  DataCell(
                    Text(
                      (res.lotId ?? res.spotId).length > 16
                          ? '${(res.lotId ?? res.spotId).substring(0, 16)}...'
                          : (res.lotId ?? res.spotId),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                  ),
                  DataCell(Text(res.formattedParkingTime)),
                  DataCell(Text(res.formattedLeavingTime)),
                  DataCell(
                    Text(
                      res.parkingCost != null
                          ? '₹${res.parkingCost!.toStringAsFixed(2)}'
                          : 'N/A',
                    ),
                  ),
                  // FIXED: Conditional Release button for current (active) reservation
                  DataCell(
                    res.id == currentReservation?.id &&
                            currentReservation != null
                        ? SizedBox(
                            width: 80,
                            child: ElevatedButton(
                              onPressed: () => _releaseSpot(res),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                              child: Text(
                                'Release',
                                style: TextStyle(fontSize: 12),
                              ),
                            ),
                          )
                        : SizedBox.shrink(), // Empty cell for past reservations
                  ),
                ],
              ),
            )
            .toList(),
      ),
    );
  }

  // FIXED: New method to handle release
  Future<void> _releaseSpot(Reservation res) async {
    if (!mounted) return;
    final auth = context.read<AuthService>();
    final token = auth.token;
    final success = await ApiService.releaseReservation(res.id, token: token);
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Spot released! Cost: ₹${res.parkingCost?.toStringAsFixed(2) ?? '0.00'}',
          ),
        ),
      );
      await _loadData(); // Refresh history, spots, summary
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to release spot')));
    }
  }

  Widget _buildSummaryTab() {
    final occupied = summary['occupiedSpots'] ?? 0;
    final available = summary['availableSpots'] ?? 0;

    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          if (lots.isEmpty && spotsWithDetails.isEmpty)
            Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('No parking lots or spots available'),
              ),
            )
          else
            Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      'Parking Spots',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    SizedBox(height: 16),
                    SizedBox(
                      height: 200,
                      child: DoughnutChart(
                        occupied: occupied.toDouble(),
                        available: available.toDouble(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class DoughnutChart extends StatelessWidget {
  final double occupied;
  final double available;

  const DoughnutChart({
    Key? key,
    required this.occupied,
    required this.available,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PieChart(
      PieChartData(
        sections: [
          PieChartSectionData(
            value: occupied,
            color: Colors.red,
            title: 'Occupied',
          ),
          PieChartSectionData(
            value: available,
            color: Colors.green,
            title: 'Available',
          ),
        ],
        centerSpaceRadius: 40,
      ),
    );
  }
}
