import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:http/browser_client.dart' as browser;
import '../models/parking_lot.dart';
import '../models/reservation.dart';
import '../models/user.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:3000/api';

  // Use a single client; on web use BrowserClient which can send cookies
  static final http.Client _client = kIsWeb
      ? browser.BrowserClient()
      : http.Client();

  static String? _authToken;
  static void setAuthToken(String? token) => _authToken = token;

  static Map<String, String> _headers([String? token]) {
    final headers = <String, String>{'Content-Type': 'application/json'};
    final authToken = token ?? _authToken;
    if (authToken != null && authToken.isNotEmpty) {
      headers['Authorization'] = 'Bearer $authToken';
    }
    return headers;
  }

  static Uri _uri(String path) => Uri.parse('$baseUrl$path');

  static Future<http.Response> _get(String path, {String? token}) =>
      _client.get(_uri(path), headers: _headers(token));

  static Future<http.Response> _post(
    String path,
    Map<String, dynamic> body, {
    String? token,
  }) => _client.post(
    _uri(path),
    headers: _headers(token),
    body: jsonEncode(body),
  );

  static Future<http.Response> _put(
    String path,
    Map<String, dynamic> body, {
    String? token,
  }) =>
      _client.put(_uri(path), headers: _headers(token), body: jsonEncode(body));

  static Future<http.Response> _delete(String path, {String? token}) =>
      _client.delete(_uri(path), headers: _headers(token));

  // Add error handling helper
  static T _handleResponse<T>(
    http.Response response,
    T Function(Map<String, dynamic>) onSuccess,
    T defaultValue,
  ) {
    if (response.statusCode == 200 || response.statusCode == 201) {
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      return onSuccess(data);
    } else if (response.statusCode == 401) {
      print(
        'Unauthorized request to ${response.request?.url}. Token may be invalid or expired.',
      );
      // Could trigger a refresh token flow here
      return defaultValue;
    }
    print(
      'Request failed with status ${response.statusCode}: ${response.body}',
    );
    return defaultValue;
  }

  static Future<List<ParkingLot>> getParkingLots({
    String? query,
    String? token,
  }) async {
    try {
      final params = <String, String>{
        '_t': DateTime.now().millisecondsSinceEpoch.toString(),
      };
      if (query != null && query.isNotEmpty) params['query'] = query;
      final uri = _uri('/lots').replace(queryParameters: params);
      final res = await _client.get(uri, headers: _headers(token));
      print(
        'GET ${uri.toString()} status: ${res.statusCode}, body: ${res.body}',
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List<dynamic>;
        return data
            .map((e) => ParkingLot.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      // If server rejects (403) try a public endpoint (no Authorization header)
      if (res.statusCode == 403) {
        final publicUri = _uri('/lots/public').replace(queryParameters: params);
        final publicRes = await _client.get(publicUri, headers: _headers(''));
        print(
          'GET ${publicUri.toString()} status: ${publicRes.statusCode}, body: ${publicRes.body}',
        );
        if (publicRes.statusCode == 200) {
          final data = jsonDecode(publicRes.body) as List<dynamic>;
          return data
              .map((e) => ParkingLot.fromJson(e as Map<String, dynamic>))
              .toList();
        }
      }
      return [];
    } catch (e, st) {
      print('getParkingLots error: $e\n$st');
      return [];
    }
  }

  static Future<ParkingLot?> createParkingLot(
    Map<String, dynamic> data, {
    String? token,
  }) async {
    final res = await _post('/lots', data, token: token);
    print('Create lot response status: ${res.statusCode}, body: ${res.body}');
    if (res.statusCode == 201) return ParkingLot.fromJson(jsonDecode(res.body));
    return null;
  }

  static Future<ParkingLot?> updateParkingLot(
    String id,
    Map<String, dynamic> data, {
    String? token,
  }) async {
    final res = await _put('/lots/$id', data, token: token);
    if (res.statusCode == 200) return ParkingLot.fromJson(jsonDecode(res.body));
    return null;
  }

  static Future<bool> deleteParkingLot(String id) async {
    try {
      final res = await _delete('/admin/lots/$id');
      return res.statusCode == 200;
    } catch (e) {
      print('deleteParkingLot error: $e');
      return false;
    }
  }

  // Spots
  static Future<List<Map<String, dynamic>>> getSpotsWithDetails({
    String? token,
  }) async {
    try {
      final uri = Uri.parse('$baseUrl/spots/details');
      final res = await http.get(uri, headers: _headers(token));
      print('GET ${uri.toString()} status: ${res.statusCode}');
      if (res.statusCode == 200)
        return List<Map<String, dynamic>>.from(jsonDecode(res.body));

      // fallback: try again without Authorization header
      if (res.statusCode == 403) {
        final publicRes = await http.get(uri, headers: _headers(''));
        print('GET ${uri.toString()} (public) status: ${publicRes.statusCode}');
        if (publicRes.statusCode == 200)
          return List<Map<String, dynamic>>.from(jsonDecode(publicRes.body));
      }

      return [];
    } catch (e) {
      print('getSpotsWithDetails error: $e');
      return [];
    }
  }

  static Future<http.Response> getSpotDetails(
    String spotId, {
    String? token,
  }) async {
    // try with provided/stored token first
    final res = await _get('/spots/$spotId/details', token: token);
    if (res.statusCode == 403) {
      // try again without Authorization header
      return _get('/spots/$spotId/details', token: '');
    }
    return res;
  }

  // Summary
  static Future<Map<String, dynamic>> getSummary({String? token}) async {
    try {
      final uri = Uri.parse('$baseUrl/summary');
      final res = await http.get(uri, headers: _headers(token));
      print('GET ${uri.toString()} status: ${res.statusCode}');
      if (res.statusCode == 200)
        return Map<String, dynamic>.from(jsonDecode(res.body));

      // fallback to unauthenticated request if 403
      if (res.statusCode == 403) {
        final publicRes = await http.get(uri, headers: _headers(''));
        print('GET ${uri.toString()} (public) status: ${publicRes.statusCode}');
        if (publicRes.statusCode == 200)
          return Map<String, dynamic>.from(jsonDecode(publicRes.body));
      }

      return {};
    } catch (e) {
      print('getSummary error: $e');
      return {};
    }
  }

  // Reservations
  static Future<bool> reserveSpot(
    String lotId,
    String userId,
    String vehicleNumber,
  ) async {
    // FIXED: Early return if empty userId
    if (userId.isEmpty) {
      print('reserveSpot: Empty userId provided, skipping request.');
      return false;
    }

    try {
      final res = await _post('/reservations', {
        'lotId': lotId,
        'userId': userId,
        'vehicleNumber': vehicleNumber,
      });

      print(
        'POST /reservations - Status: ${res.statusCode} - Body: ${res.body}',
      );
      return res.statusCode == 201;
    } catch (e) {
      print('reserveSpot error: $e');
      return false;
    }
  }

  static Future<bool> releaseSpot(
    String reservationId,
    String userId, {
    String? token,
  }) async {
    final res = await _put('/reservations/$reservationId/release', {
      'userId': userId,
    }, token: token);
    return res.statusCode == 200;
  }

  static Future<List<dynamic>> getReservations({
    required String userId,
    String? token,
  }) async {
    if (userId.isEmpty) {
      print('getReservations: Empty userId, returning empty list.');
      return [];
    }

    try {
      final uri = Uri.parse(
        '$baseUrl/reservations',
      ).replace(queryParameters: {'userId': userId});
      final res = await http.get(uri, headers: _headers(token));
      print(
        'GET ${uri} status: ${res.statusCode}, body: ${res.body}',
      ); // FIXED: Log body for date debugging
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is List<dynamic>) return data;
        print('Unexpected reservations data type: ${data.runtimeType}');
        return [];
      }

      if (res.statusCode == 403) {
        final publicRes = await http.get(uri, headers: _headers(''));
        print(
          'GET ${uri} (public) status: ${publicRes.statusCode}, body: ${publicRes.body}',
        );
        if (publicRes.statusCode == 200) {
          final data = jsonDecode(publicRes.body);
          if (data is List<dynamic>) return data;
        }
      }

      return [];
    } catch (e) {
      print('getReservations error: $e');
      return [];
    }
  }

  // Auth
  static Future<User?> login(String username, String password) async {
    // Ensure we DO NOT send an Authorization header for login (pass empty token)
    final res = await _post('/auth/login', {
      'username': username,
      'password': password,
    }, token: '');

    return _handleResponse<User?>(res, (data) {
      final user = User.fromJson(data);
      // Store token if login successful
      setAuthToken(user.token);
      return user;
    }, null);
  }

  static void logout() {
    setAuthToken(null);
  }

  static Future<bool> releaseReservation(String resvId, {String? token}) async {
    if (resvId.isEmpty) {
      print('releaseReservation: Empty resvId, skipping.');
      return false;
    }

    try {
      final res = await _put('/reservations/$resvId/release', {}, token: token);
      print(
        'PUT /reservations/$resvId/release - Status: ${res.statusCode} - Body: ${res.body}',
      );
      return res.statusCode == 200;
    } catch (e) {
      print('releaseReservation error: $e');
      return false;
    }
  }

  static Future<User?> register(
    String username,
    String password,
    String role,
  ) async {
    // Ensure register does not accidentally include an Authorization header
    final res = await _post('/auth/register', {
      'username': username,
      'password': password,
      'role': role,
    }, token: '');
    print('POST ${_uri('/auth/register')} status: ${res.statusCode}');
    if (res.statusCode == 201) {
      final user = User.fromJson(jsonDecode(res.body));
      setAuthToken(user.token);
      return user;
    }
    return null;
  }
}
